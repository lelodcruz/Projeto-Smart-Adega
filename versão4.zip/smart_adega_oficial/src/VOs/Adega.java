package VOs;

public class Adega {

	private float valorSensor;

	public Adega() {
	}

	public Adega(Float valorSensor) {
		this.valorSensor = valorSensor;
	}
	
	public float getValorSensor() {
		return valorSensor;
	}

	public void setValorSensor(Float valorSensor) {
		this.valorSensor = valorSensor;
	}

}
